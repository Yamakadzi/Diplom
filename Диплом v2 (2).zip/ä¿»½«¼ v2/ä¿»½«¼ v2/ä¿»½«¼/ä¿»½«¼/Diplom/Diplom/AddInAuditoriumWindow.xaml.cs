﻿using Diplom.Data;
using Diplom.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddInAuditoriumWindow.xaml
    /// </summary>
    public partial class AddInAuditoriumWindow : Window
    {
        private EquipmentStockModel _selectedEquipment;
        public event EventHandler ItemAddedSuccessfully;

        public AddInAuditoriumWindow()
        {
            InitializeComponent();
            InitializeComboBoxes();
        }

        private void InitializeComboBoxes()
        {
            using (var context = new MarketContext())
            {
                var auditories = context.Auditoria.Include(a => a.IdStockNavigation).ThenInclude(a=> a.EqupmentsStocks).ToList();
               
                AuditoriaComboBox.ItemsSource = auditories;
                AuditoriaComboBox.DisplayMemberPath = "Name";

                var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
                CountryComboBox.ItemsSource = countries;

                var units = new List<string> { "шт", "упаковка", "комплект" };
                UnitComboBox.ItemsSource = units;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedEquipment != null)
            {
                var selectedAuditorium = (Auditorium)AuditoriaComboBox.SelectedItem;
                if (selectedAuditorium != null)
                {
                    using (var context = new MarketContext())
                    {
                        if (int.TryParse(CountTextBox.Text, out int count))
                        {
                            if (count <= 0 ) // Проверка на отрицательное число и число 0
                            {
                                MessageBox.Show("Введите корректное количество.");
                                return;
                            }

                            var equipmentInStock = context.EqupmentsStocks
                                .Include(es => es.IdStockNavigation)
                                .Where(es => es.IdStockNavigation.Type == "main")
                                .FirstOrDefault(es => es.IdEqupment == _selectedEquipment.IdEqupment);
                                
                            if (equipmentInStock != null && equipmentInStock.Count >= count)
                            {
                                equipmentInStock.Count -= count;
                                var existingEquipment = selectedAuditorium.IdStockNavigation.EqupmentsStocks.FirstOrDefault(es => es.IdEqupment == _selectedEquipment.IdEqupment);
                                if (existingEquipment == null)
                                {
                                    var newEquipmentInAuditorium = new EqupmentsStock
                                    {
                                        IdEqupment = _selectedEquipment.IdEqupment,
                                        IdStock = selectedAuditorium.IdStock,
                                        Count = count
                                    };

                                    context.EqupmentsStocks.Add(newEquipmentInAuditorium);
                                }
                                else 
                                {
                                    existingEquipment.Count += count;
                                    context.EqupmentsStocks.Update(existingEquipment);
                                }
                               context.SaveChanges();
                               MessageBox.Show("Оборудование успешно добавлено в аудиторию.");
                               ItemAddedSuccessfully?.Invoke(this, EventArgs.Empty);
                               this.Close();
                            }
                            else
                            {
                                MessageBox.Show($"На складе недостаточно оборудования, не хватает: {count - equipmentInStock.Count}");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Введите корректное количество.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Выберите аудиторию");
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование со склада.");
            }
        }

        private void StockButton_Click(object sender, RoutedEventArgs e)
        {
            var objectStockWindow = new ObjectStockWindow();
            objectStockWindow.EquipmentSelected += ObjectStockWindow_EquipmentSelected;
            objectStockWindow.MinWidth = 1300; 
            objectStockWindow.MinHeight = 850;
            objectStockWindow.ShowDialog();
        }

        private void ObjectStockWindow_EquipmentSelected(object sender, EquipmentStockModelEventArgs e)
        {
            _selectedEquipment = e.SelectedEquipment;
            NameTextBox.Text = _selectedEquipment.Name;
            DescriptionRichBox.Document.Blocks.Clear();
            DescriptionRichBox.Document.Blocks.Add(new Paragraph(new Run(_selectedEquipment.Description)));
            ManufacturerTextBox.Text = _selectedEquipment.Manufacturer;
            ModelTextBox.Text = _selectedEquipment.Model;
            CountryComboBox.SelectedItem = _selectedEquipment.Country;
            OkpdTextBox.Text = _selectedEquipment.Okpd;
            PriceTextBox.Text = _selectedEquipment.Price.ToString();
            UnitComboBox.SelectedItem = _selectedEquipment.Unit;
            CommentRichTextBox.Document.Blocks.Clear();
            CommentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(_selectedEquipment.Comment)));
        }
    }
}
