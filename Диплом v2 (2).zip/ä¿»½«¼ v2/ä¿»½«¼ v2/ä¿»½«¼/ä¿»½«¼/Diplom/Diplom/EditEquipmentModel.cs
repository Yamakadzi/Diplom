﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diplom
{
    public class EditEquipmentModel : INotifyPropertyChanged
    {
        public int IdEqupment { get; set; }
        public int IdStock { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string Country { get; set; }
        public string Okpd { get; set; }
        public decimal Price { get; set; }
        public int Count { get; set; }
        public string Unit { get; set; }
        public string Comment { get; set; }
        public string Type { get; set; }
        public decimal TotalPrice { get; set; }

        private bool _showSelectButton;
        public bool ShowSelectButton
        {
            get { return _showSelectButton; }
            set
            {
                if (_showSelectButton != value)
                {
                    _showSelectButton = value;
                    OnPropertyChanged(nameof(ShowSelectButton));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
