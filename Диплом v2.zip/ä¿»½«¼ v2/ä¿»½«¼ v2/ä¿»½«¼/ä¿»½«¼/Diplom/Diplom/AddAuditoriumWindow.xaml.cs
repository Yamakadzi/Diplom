﻿using Diplom.Data;
using Diplom.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddAuditoriumWindow.xaml
    /// </summary>
    public partial class AddAuditoriumWindow : Window
    {
        public event EventHandler ItemAddedSuccessfully;
        public AddAuditoriumWindow()
        {
            InitializeComponent();
            AuditoriaTextBox.PreviewTextInput += AuditoriaTextBox_PreviewTextInput;
            AuditoriaTextBox.PreviewKeyDown += AuditoriaTextBox_PreviewKeyDown;
        }

        private void AddAuditoriumButton_Click(object sender, RoutedEventArgs e)
        {
            string auditoriumName = AuditoriaTextBox.Text.Trim();

            if (string.IsNullOrEmpty(auditoriumName))
            {
                MessageBox.Show("Введите название аудитории.");
                return;
            }

            if (auditoriumName.Length > 4)
            {
                MessageBox.Show("Название аудитории не должно превышать 4 символов.");
                return;
            }

            using (var context = new MarketContext())
            {
                // Проверяем, существует ли аудитория с таким же названием
                bool auditoriumExists = context.Auditoria.Any(a => a.Name == auditoriumName);

                if (auditoriumExists)
                {
                    MessageBox.Show("Аудитория с таким названием уже существует.");
                    return;
                }

                // Создаем новый объект Stock с типом "auditorium"
                var newStock = new Stock
                {
                    Name = auditoriumName,
                    Type = "auditorium"
                };

                context.Stocks.Add(newStock);
                context.SaveChanges();

                // Создаем новый объект Auditorium и связываем его с новым складом
                var newAuditorium = new Auditorium
                {
                    Name = auditoriumName,
                    IdStock = newStock.IdStock
                };

                context.Auditoria.Add(newAuditorium);
                context.SaveChanges();

                MessageBox.Show("Аудитория успешно добавлена.");

                // Оповещаем о том, что аудитория успешно добавлена
                ItemAddedSuccessfully?.Invoke(this, EventArgs.Empty);
            }

            this.Close();
        }

        private void AuditoriaTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Разрешаем ввод только букв и цифр
            e.Handled = !IsTextAllowed(e.Text);
        }

        private void AuditoriaTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Back || e.Key == Key.Delete || e.Key == Key.Tab)
            {
                return;
            }

            if (AuditoriaTextBox.Text.Length >= 4)
            {
                e.Handled = true;
            }
        }

        private static bool IsTextAllowed(string text)
        {
            // Проверяем, что текст состоит только из букв и цифр
            return !new Regex("[^a-zA-Z0-9а-яА-Я]").IsMatch(text);
        }
    }
}
