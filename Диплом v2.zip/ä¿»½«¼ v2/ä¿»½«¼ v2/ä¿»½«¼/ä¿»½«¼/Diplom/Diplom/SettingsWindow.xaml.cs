﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();

            ServerTextBox.Text = Properties.Settings.Default.server;
            DatabaseTextBox.Text = Properties.Settings.Default.database;
            LoginTextBox.Text = Properties.Settings.Default.login;
            PasswordTextBox.Text = Properties.Settings.Default.password;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.server = ServerTextBox.Text ;
            Properties.Settings.Default.database = DatabaseTextBox.Text ;
            Properties.Settings.Default.login = LoginTextBox.Text;
            Properties.Settings.Default.password = PasswordTextBox.Text;

            Properties.Settings.Default.Save();
            Close();
        }

        private void PinCodeButton_Click(object sender, RoutedEventArgs e)
        {
            if (PinCodeTextBox.Text == Properties.Settings.Default.pincode)
            {
                PinCodeTextBox.Visibility = Visibility.Collapsed;
                PinCodeButton.Visibility = Visibility.Collapsed;
                LoginTextBox.Visibility = Visibility.Visible;
                PasswordTextBox.Visibility = Visibility.Visible;
                DatabaseTextBox.Visibility = Visibility.Visible;
                ServerTextBox.Visibility = Visibility.Visible;
                SaveButton.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Неправильный пин-код");
            }
        }
    }
}
