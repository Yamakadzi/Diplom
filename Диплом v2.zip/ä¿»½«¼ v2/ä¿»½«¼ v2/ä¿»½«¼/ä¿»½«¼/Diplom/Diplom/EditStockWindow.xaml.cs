﻿using Diplom.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для EditStockWindow.xaml
    /// </summary>
    public partial class EditStockWindow : Window
    {
        private EditEquipmentModel _equipmentToEdit;

        public EditStockWindow(EditEquipmentModel equipmentToEdit)
        {
            InitializeComponent();
            InitializeComboBoxes();
            _equipmentToEdit = equipmentToEdit;
            LoadSelectedEquipmentData();
        }

        private void InitializeComboBoxes()
        {
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

            var types = new List<string> { "Оборудование", "Расходные материалы", "Инструменты" };
            TypeComboBox.ItemsSource = types;
        }

        private void LoadSelectedEquipmentData()
        {
            NameTextBox.Text = _equipmentToEdit.Name;
            TypeComboBox.SelectedItem = _equipmentToEdit.Type;
            DescriptionRichBox.Document.Blocks.Clear();
            DescriptionRichBox.Document.Blocks.Add(new Paragraph(new Run(_equipmentToEdit.Description)));
            ManufacturerTextBox.Text = _equipmentToEdit.Manufacturer;
            ModelTextBox.Text = _equipmentToEdit.Model;
            CountryComboBox.SelectedItem = _equipmentToEdit.Country;
            OkpdTextBox.Text = _equipmentToEdit.Okpd;
            PriceTextBox.Text = _equipmentToEdit.Price.ToString();
            CountTextBox.Text = _equipmentToEdit.Count.ToString();
            UnitComboBox.SelectedItem = _equipmentToEdit.Unit;
            CommentRichTextBox.Document.Blocks.Clear();
            CommentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(_equipmentToEdit.Comment)));
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(CountTextBox.Text, out int count))
            {
                if (count >= 0)
                {
                    using (var context = new MarketContext())
                    {
                        var equipmentInStock = context.EqupmentsStocks.FirstOrDefault(es => es.IdEqupment == _equipmentToEdit.IdEqupment && es.IdStock == _equipmentToEdit.IdStock);

                        if (equipmentInStock != null)
                        {
                            equipmentInStock.Count = count;

                            context.SaveChanges();
                            MessageBox.Show("Данные успешно обновлены.");
                            this.Close();

                            var mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                            if (mainWindow != null)
                            {
                                var infoStockPage = mainWindow.Content as InfoStockPage;
                                infoStockPage?.LoadStockEquipment(infoStockPage.TabControl.SelectedItem is TabItem selectedItem ? selectedItem.Header.ToString() : null);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ошибка при обновлении данных.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Количество не может быть отрицательным.");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректное значение для количества.");
            }
        }
    }
}
