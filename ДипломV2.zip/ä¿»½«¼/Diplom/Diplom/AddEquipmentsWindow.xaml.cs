﻿using Diplom.Data;
using Diplom.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddEquipmentsWindow.xaml
    /// </summary>
    public partial class AddEquipmentsWindow : Window
    {
        public event EventHandler ItemAddedSuccessfully;
        public AddEquipmentsWindow()
        {
            InitializeComponent();
            InitializeComboBoxes();
        }
        private void InitializeComboBoxes()
        {
            // Заполнение CountryComboBox
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            // Заполнение UnitComboBox
            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

            var types = new List<string> { "Оборудование", "Расходные материалы", "Инструменты" };
            TypeComboBox.ItemsSource = types;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text.Trim();
            string type = TypeComboBox.SelectedItem as string;
            string description = new TextRange(DescriptionRichBox.Document.ContentStart, DescriptionRichBox.Document.ContentEnd).Text.Trim();
            string manufacturer = ManufacturerTextBox.Text.Trim();
            string? model = ModelTextBox.Text.Trim();
            string country = CountryComboBox.SelectedItem as string;
            string okpd = OkpdTextBox.Text.Trim();
            string unit = UnitComboBox.SelectedItem as string;
            decimal price;
            string comment = new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text.Trim();

            // Проверка ввода данных
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(type) || string.IsNullOrEmpty(description) ||
                string.IsNullOrEmpty(manufacturer) || string.IsNullOrEmpty(country) || string.IsNullOrEmpty(okpd) ||
                string.IsNullOrEmpty(unit) || !decimal.TryParse(PriceTextBox.Text.Trim(), out price))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля правильно.");
                return;
            }

            if (string.IsNullOrEmpty(comment))
            {
                comment = "Без комментария";
            }


            // Создание нового предмета
            var newEquipment = new Equipment
            {
                Name = name,
                Type = type,
                Description = description,
                Manufacturer = manufacturer,
                Model = model,
                Country = country,
                Okpd = okpd,
                Unit = unit,
                Price = price,
                Comment = comment
            };

            // Сохранение в базу данных
            using (var context = new MarketContext())
            {
                context.Equipments.Add(newEquipment);
                context.SaveChanges();
            }

            MessageBox.Show("Предмет успешно добавлен.");
            ClearForm();
            ItemAddedSuccessfully?.Invoke(this, EventArgs.Empty);
        }

        private void ClearForm()
        {
            NameTextBox.Clear();
            TypeComboBox.SelectedIndex = -1;
            DescriptionRichBox.Document.Blocks.Clear();
            ManufacturerTextBox.Clear();
            ModelTextBox.Clear();
            CountryComboBox.SelectedIndex = -1;
            OkpdTextBox.Clear();
            PriceTextBox.Clear();
            UnitComboBox.SelectedIndex = -1;
            CommentRichTextBox.Document.Blocks.Clear();
        }
    }
}
