﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diplom
{
    public class EditEquipmentModel
    {
        public int IdEqupment { get; set; }
        public int IdStock { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string Country { get; set; }
        public string Okpd { get; set; }
        public decimal Price { get; set; }
        public int Count { get; set; }
        public string Unit { get; set; }
        public string Comment { get; set; }
        public string Type { get; set; }
        public decimal TotalPrice { get; set; }

    }
}
