﻿using Diplom.Data;
using Diplom.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для InfoStockPage.xaml
    /// </summary>
    public partial class InfoStockPage : Page
    {
        private Dictionary<string, List<EditEquipmentModel>> _equipmentByType; // Сохраняем оригинальный список оборудования

        public TabControl TabControl => tabControl;
        public InfoStockPage()
        {
            InitializeComponent();
            _equipmentByType = new Dictionary<string, List<EditEquipmentModel>>();
            LoadStockEquipment();

        }
        public void LoadStockEquipment(string selectedType = null)
        {
            using (var context = new MarketContext())
            {
                IQueryable<EqupmentsStock> equipmentQuery = context.Stocks
                    .Where(s => s.Type == "main")
                    .SelectMany(s => s.EqupmentsStocks);

                var equipmentList = equipmentQuery
                    .Select(es => new EditEquipmentModel
                    {
                        IdEqupment = es.IdEqupmentNavigation.IdEquipment,
                        IdStock = es.IdStock,
                        Name = es.IdEqupmentNavigation.Name,
                        Description = es.IdEqupmentNavigation.Description,
                        Manufacturer = es.IdEqupmentNavigation.Manufacturer,
                        Model = es.IdEqupmentNavigation.Model,
                        Country = es.IdEqupmentNavigation.Country,
                        Okpd = es.IdEqupmentNavigation.Okpd,
                        Price = es.IdEqupmentNavigation.Price,
                        Count = es.Count,
                        Unit = es.IdEqupmentNavigation.Unit,
                        Comment = string.IsNullOrEmpty(es.IdEqupmentNavigation.Comment) ? "Без комментария" : es.IdEqupmentNavigation.Comment,
                        Type = es.IdEqupmentNavigation.Type,
                        TotalPrice = es.IdEqupmentNavigation.Price * es.Count // Рассчитываем общую стоимость
                    })
                    .ToList();

                _equipmentByType["Все типы"] = equipmentList;
                _equipmentByType["Инструменты"] = equipmentList.Where(e => e.Type == "Инструменты").ToList();
                _equipmentByType["Оборудование"] = equipmentList.Where(e => e.Type == "Оборудование").ToList();
                _equipmentByType["Расходные материалы"] = equipmentList.Where(e => e.Type == "Расходные материалы").ToList();

                UpdateFilteredEquipmentList(tabControl.SelectedItem as TabItem);
            }
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl && tabControl.SelectedItem is TabItem selectedItem)
            {
                UpdateFilteredEquipmentList(selectedItem);
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateFilteredEquipmentList(tabControl.SelectedItem as TabItem);
        }

        private void UpdateFilteredEquipmentList(TabItem selectedTab = null)
        {
            var filter = SearchTextBox.Text.ToLower();
            var selectedType = (selectedTab != null && selectedTab.Header.ToString() != "Все типы") ? selectedTab.Header.ToString() : null;

            List<EditEquipmentModel> filteredList;

            if (selectedType != null)
            {
                filteredList = _equipmentByType[selectedType]
                    .Where(item =>
                    {
                        dynamic itm = item; // Приводим к dynamic для доступа к свойствам
                        return (itm.Name.ToLower().Contains(filter) ||
                                itm.Description.ToLower().Contains(filter) ||
                                itm.Manufacturer.ToLower().Contains(filter) ||
                                (itm.Model != null && itm.Model.ToLower().Contains(filter)) ||
                                itm.Country.ToLower().Contains(filter) ||
                                itm.Okpd.ToLower().Contains(filter));
                    })
                    .ToList();
            }
            else
            {
                filteredList = _equipmentByType["Все типы"]
                    .Where(item =>
                    {
                        dynamic itm = item; // Приводим к dynamic для доступа к свойствам
                        return (itm.Name.ToLower().Contains(filter) ||
                                itm.Description.ToLower().Contains(filter) ||
                                itm.Manufacturer.ToLower().Contains(filter) ||
                                (itm.Model != null && itm.Model.ToLower().Contains(filter)) ||
                                itm.Country.ToLower().Contains(filter) ||
                                itm.Okpd.ToLower().Contains(filter));
                    })
                    .ToList();
            }

            DGridProductsList.ItemsSource = filteredList.Distinct().ToList();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (DGridProductsList.SelectedItem is EditEquipmentModel selectedEquipment && tabControl.SelectedItem is TabItem selectedItem)
            {
                EditStockWindow editWindow = new EditStockWindow(selectedEquipment);
                editWindow.ShowDialog();
                LoadStockEquipment(selectedItem.Header.ToString());
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите элемент для редактирования.");
            }
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (DGridProductsList.SelectedItem is EditEquipmentModel selectedEquipment)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить {selectedEquipment.Name}?",
                                             "Подтверждение удаления",
                                             MessageBoxButton.YesNo,
                                             MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    using (var context = new MarketContext())
                    {
                        var equipmentStock = context.EqupmentsStocks
                            .FirstOrDefault(es => es.IdEqupment == selectedEquipment.IdEqupment && es.IdStock == selectedEquipment.IdStock);

                        if (equipmentStock != null)
                        {
                            context.EqupmentsStocks.Remove(equipmentStock);
                            context.SaveChanges();
                        }
                    }

                    // Обновляем список оборудования
                    var selectedTabHeader = (tabControl.SelectedItem as TabItem)?.Header.ToString();
                    LoadStockEquipment(selectedTabHeader);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите элемент для удаления.");
            }
        }

        private void AddInStock_Click(object sender, RoutedEventArgs e)
        {
            InfoEquipmentsPage infoEquipmentsPage = new InfoEquipmentsPage(showSelectButton: true); // Передаем true, чтобы показать кнопку "Выбрать"

            Window window = new Window
            {
                Title = "Информация о предметах",
                Content = infoEquipmentsPage,
                MinWidth = 800,
                MinHeight = 450,
            };

            infoEquipmentsPage.ItemSelected += (s, selectedItem) =>
            {
                AddInStockWindow addInStockWindow = new AddInStockWindow(selectedItem.Type);
                addInStockWindow.FillFields(selectedItem);
                addInStockWindow.ItemAddedSuccessfully += AddInStockWindow_ItemAddedSuccessfully;
                addInStockWindow.Show();
                window.Close();
            };

            window.ShowDialog();
        }
        private void AddInStockWindow_ItemAddedSuccessfully(object sender, EventArgs e)
        {
            if (tabControl.SelectedItem is TabItem selectedItem)
            {
                LoadStockEquipment(selectedItem.Header.ToString());
            }
        }
    }
}
