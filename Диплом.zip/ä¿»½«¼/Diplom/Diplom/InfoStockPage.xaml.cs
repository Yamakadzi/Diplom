﻿using Diplom.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для InfoStockPage.xaml
    /// </summary>
    public partial class InfoStockPage : Page
    {
        private List<dynamic> _originalEquipmentList; // Сохраняем оригинальный список оборудования
        public InfoStockPage()
        {
            InitializeComponent();
            LoadStockEquipment();

        }
        private void LoadStockEquipment()
        {
            using (var context = new MarketContext())
            {
                var equipmentList = context.Stocks
                    .Where(s => s.Type == "main")
                    .SelectMany(s => s.EqupmentsStocks)
                    .Select(es => new
                    {
                        es.IdEqupmentNavigation.Name,
                        es.IdEqupmentNavigation.Description,
                        es.IdEqupmentNavigation.Manufacturer,
                        es.IdEqupmentNavigation.Model,
                        es.IdEqupmentNavigation.Country,
                        es.IdEqupmentNavigation.Okpd,
                        es.IdEqupmentNavigation.Price,
                        es.IdEqupmentNavigation.Type,
                        es.Count,
                        es.IdEqupmentNavigation.Unit,
                        TotalPrice = es.IdEqupmentNavigation.Price * es.Count,
                        Сomment = string.IsNullOrEmpty(es.IdEqupmentNavigation.Сomment) ? "Без комментария" : es.IdEqupmentNavigation.Сomment
                    })
                    .ToList<dynamic>();

                _originalEquipmentList = equipmentList; // Сохраняем оригинальный список
                DGridProductsList.ItemsSource = _originalEquipmentList;
            }
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl && tabControl.SelectedItem is TabItem selectedItem)
            {
                UpdateFilteredEquipmentList(selectedItem);
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateFilteredEquipmentList();
        }

        private void UpdateFilteredEquipmentList(TabItem selectedTab = null)
        {
            var filter = SearchTextBox.Text.ToLower();
            var selectedType = (selectedTab != null && selectedTab.Header.ToString() != "Все типы") ? selectedTab.Header.ToString() : null;

            var filteredList = _originalEquipmentList
                .Where(item =>
                {
                    dynamic itm = item; // Приводим к dynamic для доступа к свойствам
                    return ((selectedType == null || itm.Type == selectedType) && // Проверяем тип
                           (itm.Name.ToLower().Contains(filter) ||
                           itm.Description.ToLower().Contains(filter) ||
                           itm.Manufacturer.ToLower().Contains(filter) ||
                           (itm.Model != null && itm.Model.ToLower().Contains(filter)) ||
                           itm.Country.ToLower().Contains(filter) ||
                           itm.Okpd.ToLower().Contains(filter)));
                })
                .ToList();

            DGridProductsList.ItemsSource = filteredList;
        }

        private void MoveObject_Click(object sender, RoutedEventArgs e)
        {

        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AddInStock_Click(object sender, RoutedEventArgs e)
        {
            AddInStockWindow addInStockWindow = new AddInStockWindow();
            addInStockWindow.ItemAddedSuccessfully += AddInStockWindow_ItemAddedSuccessfully;
            addInStockWindow.ShowDialog();
        }
        private void AddInStockWindow_ItemAddedSuccessfully(object sender, EventArgs e)
        {
            LoadStockEquipment();
        }
    }
}
