﻿using System;
using System.Collections.Generic;
using Diplom.Models;
using Microsoft.EntityFrameworkCore;

namespace Diplom.Data;

public partial class MarketContext : DbContext
{
    public MarketContext()
    {
    }

    public MarketContext(DbContextOptions<MarketContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Auditorium> Auditoria { get; set; }

    public virtual DbSet<Equipment> Equipments { get; set; }

    public virtual DbSet<EqupmentsStock> EqupmentsStocks { get; set; }

    public virtual DbSet<Stock> Stocks { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=DESKTOP-GURUASM;initial catalog =practice;persist security info=True; user id=admin;password=admin;TrustServerCertificate=true;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Auditorium>(entity =>
        {
            entity.HasKey(e => e.IdAuditorium);

            entity.ToTable("Auditorium");

            entity.HasIndex(e => e.IdStock, "IX_Auditorium").IsUnique();

            entity.Property(e => e.Name).HasMaxLength(4);

            entity.HasOne(d => d.IdStockNavigation).WithOne(p => p.Auditorium)
                .HasForeignKey<Auditorium>(d => d.IdStock)
                .HasConstraintName("FK_Auditorium_Stock");
        });

        modelBuilder.Entity<Equipment>(entity =>
        {
            entity.HasKey(e => e.IdEquipment).HasName("PK_InformationEquipment");

            entity.Property(e => e.Country).HasMaxLength(100);
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Manufacturer).HasMaxLength(100);
            entity.Property(e => e.Model).HasMaxLength(100);
            entity.Property(e => e.Name).HasMaxLength(200);
            entity.Property(e => e.Okpd).HasMaxLength(50);
            entity.Property(e => e.Price).HasColumnType("decimal(8, 2)");
            entity.Property(e => e.Type).HasMaxLength(50);
            entity.Property(e => e.Unit).HasMaxLength(50);
            entity.Property(e => e.Сomment).HasMaxLength(500);
        });

        modelBuilder.Entity<EqupmentsStock>(entity =>
        {
            entity.HasKey(e => new { e.IdEqupment, e.IdStock });

            entity.HasOne(d => d.IdEqupmentNavigation).WithMany(p => p.EqupmentsStocks)
                .HasForeignKey(d => d.IdEqupment)
                .HasConstraintName("FK_EqupmentsStocks_Equipments");

            entity.HasOne(d => d.IdStockNavigation).WithMany(p => p.EqupmentsStocks)
                .HasForeignKey(d => d.IdStock)
                .HasConstraintName("FK_EqupmentsStocks_Stock");
        });

        modelBuilder.Entity<Stock>(entity =>
        {
            entity.HasKey(e => e.IdStock);

            entity.ToTable("Stock");

            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.IdUser);

            entity.HasIndex(e => e.Login, "Uq_Login").IsUnique();

            entity.Property(e => e.IdUser).HasColumnName("idUser");
            entity.Property(e => e.Login)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
