﻿using Diplom.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AuthorizatonWindow.xaml
    /// </summary>
    public partial class AuthorizatonWindow : Window
    {
        public AuthorizatonWindow()
        {
            InitializeComponent();
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using var context = new MarketContext();
                var user = context.Users.FirstOrDefault(u => u.Login == LoginTextBox.Text && u.Password == PasswordBox.Password);

                if (user != null)
                {
                    MessageBox.Show($"Здравствуйте! {user.Login}");
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Логин или пароль неправильный");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
