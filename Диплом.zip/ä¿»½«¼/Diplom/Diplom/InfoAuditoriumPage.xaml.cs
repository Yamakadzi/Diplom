﻿using Diplom.Data;
using Diplom.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для InfoAuditoriumPage.xaml
    /// </summary>
    public partial class InfoAuditoriumPage : Page
    {
        private List<dynamic> _originalEquipmentList; // Сохраняем оригинальный список оборудования
        public InfoAuditoriumPage()
        {
            InitializeComponent();
            LoadAuditoriums();
            NameAuditoriumComboBox.SelectedIndex = 0;
        }
        private void LoadAuditoriums()
        {
            using (var context = new MarketContext())
            {
                var auditoriums = context.Auditoria.ToList();
                NameAuditoriumComboBox.ItemsSource = auditoriums;
                NameAuditoriumComboBox.DisplayMemberPath = "Name"; // Отображаемое имя
                NameAuditoriumComboBox.SelectedValuePath = "IdAuditorium"; // Значение

                var defaultAuditorium = auditoriums.FirstOrDefault(a => a.IdAuditorium == 1); // ID 1 для аудитории 0109
                if (defaultAuditorium != null)
                {
                    NameAuditoriumComboBox.SelectedItem = defaultAuditorium;
                    LoadAuditoriumEquipment(defaultAuditorium.IdAuditorium, "Все типы", "");
                }
            }
        }

        private void NameAuditoriumComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (NameAuditoriumComboBox.SelectedItem != null)
            {
                var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                var selectedTabHeader = (TabControl.SelectedItem as TabItem)?.Header.ToString();
                LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
            }
        }

        private void LoadAuditoriumEquipment(int auditoriumId, string selectedTabHeader, string searchText)
        {
            using (var context = new MarketContext())
            {
                var equipmentList = context.Auditoria
                    .Where(a => a.IdAuditorium == auditoriumId)
                    .SelectMany(a => a.IdStockNavigation.EqupmentsStocks)
                    .Select(es => new
                    {
                        es.IdEqupmentNavigation.Name,
                        es.IdEqupmentNavigation.Description,
                        es.IdEqupmentNavigation.Manufacturer,
                        es.IdEqupmentNavigation.Model,
                        es.IdEqupmentNavigation.Country,
                        es.IdEqupmentNavigation.Okpd,
                        es.IdEqupmentNavigation.Price,
                        es.Count,
                        es.IdEqupmentNavigation.Unit,
                        TotalPrice = es.IdEqupmentNavigation.Price * es.Count, // Вычисляем общую сумму
                        Сomment = string.IsNullOrEmpty(es.IdEqupmentNavigation.Сomment) ? "Без комментария" : es.IdEqupmentNavigation.Сomment,
                        es.IdEqupmentNavigation.Type // добавляем поле Type для фильтрации
                    })
                    .ToList<dynamic>(); // Преобразуем в List<dynamic>

                if (selectedTabHeader != "Все типы")
                {
                    equipmentList = equipmentList
                        .Where(item => item.Type == selectedTabHeader)
                        .ToList();
                }

                if (!string.IsNullOrEmpty(searchText))
                {
                    var filter = searchText.ToLower();
                    equipmentList = equipmentList
                        .Where(item =>
                        {
                            dynamic itm = item; // Приводим к dynamic для доступа к свойствам
                            return itm.Name.ToLower().Contains(filter) ||
                                   itm.Description.ToLower().Contains(filter) ||
                                   itm.Manufacturer.ToLower().Contains(filter) ||
                                   (itm.Model != null && itm.Model.ToLower().Contains(filter)) || // Проверка на null перед вызовом ToLower()
                                   itm.Country.ToLower().Contains(filter) ||
                                   itm.Okpd.ToLower().Contains(filter);

                        })
                        .ToList();
                }

                _originalEquipmentList = equipmentList; // Сохраняем оригинальный список
                DGridProductsList.ItemsSource = _originalEquipmentList;
            }
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl && tabControl.SelectedItem is TabItem selectedItem)
            {
                var selectedTabHeader = selectedItem.Header.ToString();
                if (NameAuditoriumComboBox.SelectedItem != null)
                {
                    var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                    LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
                }
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (NameAuditoriumComboBox.SelectedItem != null)
            {
                var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                var selectedTabHeader = (TabControl.SelectedItem as TabItem)?.Header.ToString();
                LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
            }
        }
        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
           
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
          
        }

        private void AddInAuditoriumButton_Click(object sender, RoutedEventArgs e)
        {
            AddInAuditoriumWindow addInAuditoriumWindow = new AddInAuditoriumWindow();
            addInAuditoriumWindow.ShowDialog();
        }
    }
}
