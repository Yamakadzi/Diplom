﻿using ClosedXML.Excel;
using Diplom.Data;
using Diplom.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для InfoAuditoriumPage.xaml
    /// </summary>
    public partial class InfoAuditoriumPage : Page, INotifyPropertyChanged
    {
        private Visibility _exportButtonVisibility;
        private List<dynamic> _originalEquipmentList;

        public Visibility ExportButtonVisibility
        {
            get => _exportButtonVisibility;
            set
            {
                if (_exportButtonVisibility != value)
                {
                    _exportButtonVisibility = value;
                    OnPropertyChanged(nameof(ExportButtonVisibility));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public InfoAuditoriumPage()
        {
            InitializeComponent();
            DataContext = this;
            LoadAuditoriums();
            NameAuditoriumComboBox.SelectedIndex = 0;
            ExportButtonVisibility = Visibility.Collapsed;
        }

        private void LoadAuditoriums()
        {
            using (var context = new MarketContext())
            {
                var auditoriums = context.Auditoria.ToList();
                NameAuditoriumComboBox.ItemsSource = auditoriums;
                NameAuditoriumComboBox.DisplayMemberPath = "Name";
                NameAuditoriumComboBox.SelectedValuePath = "IdAuditorium";

                var defaultAuditorium = auditoriums.FirstOrDefault(a => a.IdAuditorium == 1);
                if (defaultAuditorium != null)
                {
                    NameAuditoriumComboBox.SelectedItem = defaultAuditorium;
                    LoadAuditoriumEquipment(defaultAuditorium.IdAuditorium, "Все типы", "");
                }
            }
        }

        private void NameAuditoriumComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (NameAuditoriumComboBox.SelectedItem != null)
            {
                var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                var selectedTabHeader = (TabControl.SelectedItem as TabItem)?.Header.ToString();
                LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
            }
        }

        private void LoadAuditoriumEquipment(int auditoriumId, string selectedTabHeader, string searchText)
        {
            using (var context = new MarketContext())
            {
                var equipmentList = context.Auditoria
                    .Where(a => a.IdAuditorium == auditoriumId)
                    .SelectMany(a => a.IdStockNavigation.EqupmentsStocks)
                    .Select(es => new AuditoriumEquipment
                    {
                        Name = es.IdEqupmentNavigation.Name,
                        Description = es.IdEqupmentNavigation.Description,
                        Manufacturer = es.IdEqupmentNavigation.Manufacturer,
                        Model = es.IdEqupmentNavigation.Model,
                        Country = es.IdEqupmentNavigation.Country,
                        Okpd = es.IdEqupmentNavigation.Okpd,
                        Price = es.IdEqupmentNavigation.Price,
                        Count = es.Count,
                        Unit = es.IdEqupmentNavigation.Unit,
                        TotalPrice = es.IdEqupmentNavigation.Price * es.Count,
                        Comment = string.IsNullOrEmpty(es.IdEqupmentNavigation.Comment) ? "Без комментария" : es.IdEqupmentNavigation.Comment,
                        Type = es.IdEqupmentNavigation.Type,
                        IdEquipment = es.IdEqupmentNavigation.IdEquipment,
                        IdStock = es.IdStockNavigation.IdStock
                    })
                    .ToList();

                if (selectedTabHeader != "Все типы")
                {
                    equipmentList = equipmentList
                        .Where(item => item.Type == selectedTabHeader)
                        .ToList();
                }

                if (!string.IsNullOrEmpty(searchText))
                {
                    var filter = searchText.ToLower();
                    equipmentList = equipmentList
                        .Where(item =>
                            item.Name.ToLower().Contains(filter) ||
                            item.Description.ToLower().Contains(filter) ||
                            item.Manufacturer.ToLower().Contains(filter) ||
                            (item.Model != null && item.Model.ToLower().Contains(filter)) ||
                            item.Country.ToLower().Contains(filter) ||
                            item.Okpd.ToLower().Contains(filter))
                        .ToList();
                }

                _originalEquipmentList = equipmentList.Cast<object>().ToList();
                DGridProductsList.ItemsSource = _originalEquipmentList;
            }
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl && tabControl.SelectedItem is TabItem selectedItem)
            {
                var selectedTabHeader = selectedItem.Header.ToString();
                ExportButtonVisibility = selectedTabHeader == "Расходные материалы" ? Visibility.Visible : Visibility.Collapsed;

                Debug.WriteLine($"Selected Tab: {selectedTabHeader}, ExportButtonVisibility: {ExportButtonVisibility}");

                if (NameAuditoriumComboBox.SelectedItem != null)
                {
                    var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                    LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
                }
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (NameAuditoriumComboBox.SelectedItem != null)
            {
                var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                var selectedTabHeader = (TabControl.SelectedItem as TabItem)?.Header.ToString();
                LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
            }
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is AuditoriumEquipment item)
            {
                var result = MessageBox.Show($"Вы действительно хотите удалить '{item.Name}'?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.No)
                {
                    return;
                }

                using (var context = new MarketContext())
                {
                    var equipmentId = item.IdEquipment;
                    var stockId = item.IdStock;

                    var equipmentStock = context.EqupmentsStocks
                        .FirstOrDefault(es => es.IdEqupment == equipmentId && es.IdStock == stockId);

                    if (equipmentStock != null)
                    {
                        context.EqupmentsStocks.Remove(equipmentStock);
                        context.SaveChanges();

                        var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                        var selectedTabHeader = (TabControl.SelectedItem as TabItem)?.Header.ToString();
                        LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось найти элемент для удаления.");
                    }
                }
            }
        }

        private void AddInAuditoriumButton_Click(object sender, RoutedEventArgs e)
        {
            AddInAuditoriumWindow addInAuditoriumWindow = new AddInAuditoriumWindow();
            addInAuditoriumWindow.ItemAddedSuccessfully += (s, args) =>
            {
                // Обновление данных при успешном добавлении предмета
                var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                var selectedTabHeader = (TabControl.SelectedItem as TabItem)?.Header.ToString();
                LoadAuditoriumEquipment(selectedAuditorium.IdAuditorium, selectedTabHeader, SearchTextBox.Text);
            };
            addInAuditoriumWindow.ShowDialog();
        }

        private void AddAuditorimButton_Click(object sender, RoutedEventArgs e)
        {
            AddAuditoriumWindow addAuditoriumWindow = new AddAuditoriumWindow();
            addAuditoriumWindow.ItemAddedSuccessfully += (s, args) => LoadAuditoriums();
            addAuditoriumWindow.ShowDialog();
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            if (NameAuditoriumComboBox.SelectedItem != null)
            {
                var selectedAuditorium = (Auditorium)NameAuditoriumComboBox.SelectedItem;
                var consumables = DGridProductsList.ItemsSource.Cast<AuditoriumEquipment>().Where(eq => eq.Type == "Расходные материалы").ToList();

                if (consumables.Any())
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog
                    {
                        Filter = "Excel files (*.xlsx)|*.xlsx",
                        FileName = $"Расходные материалы для {selectedAuditorium.Name}.xlsx"
                    };

                    if (saveFileDialog.ShowDialog() == true)
                    {
                        using (var workbook = new XLWorkbook())
                        {
                            var worksheet = workbook.Worksheets.Add("Расходные материалы");
                            worksheet.Cell(1, 1).Value = $"Расходные материалы для аудитории: {selectedAuditorium.Name}";
                            worksheet.Cell(2, 1).Value = "Наименование";
                            worksheet.Cell(2, 2).Value = "Описание";
                            worksheet.Cell(2, 3).Value = "Производитель";
                            worksheet.Cell(2, 4).Value = "Модель";
                            worksheet.Cell(2, 5).Value = "Страна производства";
                            worksheet.Cell(2, 6).Value = "ОКПД-2";
                            worksheet.Cell(2, 7).Value = "Стоимость";
                            worksheet.Cell(2, 8).Value = "Количество";
                            worksheet.Cell(2, 9).Value = "Единица измерения";
                            worksheet.Cell(2, 10).Value = "Сумма";
                            worksheet.Cell(2, 11).Value = "Комментарий";

                            for (int i = 0; i < consumables.Count; i++)
                            {
                                var item = consumables[i];
                                worksheet.Cell(i + 3, 1).Value = item.Name;
                                worksheet.Cell(i + 3, 2).Value = item.Description;
                                worksheet.Cell(i + 3, 3).Value = item.Manufacturer;
                                worksheet.Cell(i + 3, 4).Value = item.Model;
                                worksheet.Cell(i + 3, 5).Value = item.Country;
                                worksheet.Cell(i + 3, 6).Value = item.Okpd;
                                worksheet.Cell(i + 3, 7).Value = item.Price;
                                worksheet.Cell(i + 3, 8).Value = item.Count;
                                worksheet.Cell(i + 3, 9).Value = item.Unit;
                                worksheet.Cell(i + 3, 10).Value = item.TotalPrice;
                                worksheet.Cell(i + 3, 11).Value = item.Comment;
                            }
                            worksheet.Columns().AdjustToContents();
                            workbook.SaveAs(saveFileDialog.FileName);
                            MessageBox.Show("Данные успешно экспортированы.", "Экспорт завершен", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("В выбранной аудитории отсутствуют расходные материалы.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Выберите аудиторию для экспорта данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
