﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddInAuditoriumWindow.xaml
    /// </summary>
    public partial class AddInAuditoriumWindow : Window
    {
        public AddInAuditoriumWindow()
        {
            InitializeComponent();
            InitializeComboBoxes();
        }

        private void InitializeComboBoxes()
        {
            // Заполнение AuditoriaComboBox
            var auditoriaItems = new List<string> { "0109", "0110", "0111", "0112" };
            AuditoriaComboBox.ItemsSource = auditoriaItems;

            // Заполнение CountryComboBox
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            // Заполнение UnitComboBox
            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Обработчик для кнопки "Сохранить"
            var selectedAuditorium = AuditoriaComboBox.SelectedItem?.ToString();
            var name = NameTextBox.Text;
            var description = new TextRange(DescriptionRichBox.Document.ContentStart, DescriptionRichBox.Document.ContentEnd).Text;
            var manufacturer = ManufacturerTextBox.Text;
            var model = ModelTextBox.Text;
            var country = CountryComboBox.SelectedItem?.ToString();
            var okpd = OkpdTextBox.Text;
            var price = PriceTextBox.Text;
            var count = CountTextBox.Text;
            var unit = UnitComboBox.SelectedItem?.ToString();
            var comment = new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text;

            // Логика сохранения данных в базу данных или другое хранилище
        }
    }
}
