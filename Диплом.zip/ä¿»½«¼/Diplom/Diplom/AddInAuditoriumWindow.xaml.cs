﻿using Diplom.Data;
using Diplom.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddInAuditoriumWindow.xaml
    /// </summary>
    public partial class AddInAuditoriumWindow : Window
    {
        private EquipmentStockModel _selectedEquipment;

        public AddInAuditoriumWindow()
        {
            InitializeComponent();
            InitializeComboBoxes();
        }

        private Dictionary<string, int> auditoriumToStockIdMapping = new Dictionary<string, int>
        {
            { "0109", 1 },
            { "0110", 3 },
            { "0111", 5 },
            { "0112", 7 }
        };

        private void InitializeComboBoxes()
        {
            var auditoriaItems = new List<string> { "0109", "0110", "0111", "0112" };
            AuditoriaComboBox.ItemsSource = auditoriaItems;

            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedEquipment != null)
            {
                if (AuditoriaComboBox.SelectedItem != null && auditoriumToStockIdMapping.ContainsKey(AuditoriaComboBox.SelectedItem.ToString()))
                {
                    int selectedStockId = auditoriumToStockIdMapping[AuditoriaComboBox.SelectedItem.ToString()];

                    using (var context = new MarketContext())
                    {
                        var selectedAuditorium = AuditoriaComboBox.SelectedItem?.ToString();
                        if (int.TryParse(CountTextBox.Text, out int count))
                        {
                            var equipmentInStock = context.EqupmentsStocks
                                .AsNoTracking() // Явно указываем не отслеживать сущность
                                .FirstOrDefault(es => es.IdEqupment == _selectedEquipment.IdEqupment && es.IdStock == selectedStockId);

                            if (equipmentInStock != null && equipmentInStock.Count >= count)
                            {
                                equipmentInStock.Count -= count;

                                var newEquipmentInAuditorium = new EqupmentsStock
                                {
                                    IdEqupment = _selectedEquipment.IdEqupment,
                                    IdStock = selectedStockId,
                                    Count = count
                                };

                                var newEquipment = new Equipment
                                {
                                    Name = _selectedEquipment.Name,
                                    Type = _selectedEquipment.Type,
                                    Description = _selectedEquipment.Description,
                                    Manufacturer = _selectedEquipment.Manufacturer,
                                    Model = _selectedEquipment.Model,
                                    Country = _selectedEquipment.Country,
                                    Okpd = _selectedEquipment.Okpd,
                                    Unit = _selectedEquipment.Unit,
                                    Price = _selectedEquipment.Price,
                                    Comment = _selectedEquipment.Comment,
                                };

                                // Привязываем новое оборудование к аудитории
                                newEquipment.EqupmentsStocks.Add(newEquipmentInAuditorium);

                                context.Equipments.Add(newEquipment);
                                context.SaveChanges();

                                MessageBox.Show("Оборудование успешно добавлено в аудиторию.");
                            }
                            else
                            {
                                MessageBox.Show("На складе недостаточно оборудования.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Введите корректное количество.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Выберите аудиторию и убедитесь, что она связана с складом в вашем словаре.");
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование со склада.");
            }
        }

        private void StockButton_Click(object sender, RoutedEventArgs e)
        {
            var objectStockWindow = new ObjectStockWindow();
            objectStockWindow.EquipmentSelected += ObjectStockWindow_EquipmentSelected;
            objectStockWindow.ShowDialog();
        }

        private void ObjectStockWindow_EquipmentSelected(object sender, EquipmentStockModelEventArgs e)
        {
            _selectedEquipment = e.SelectedEquipment;
            NameTextBox.Text = _selectedEquipment.Name;
            DescriptionRichBox.Document.Blocks.Clear();
            DescriptionRichBox.Document.Blocks.Add(new Paragraph(new Run(_selectedEquipment.Description)));
            ManufacturerTextBox.Text = _selectedEquipment.Manufacturer;
            ModelTextBox.Text = _selectedEquipment.Model;
            CountryComboBox.SelectedItem = _selectedEquipment.Country;
            OkpdTextBox.Text = _selectedEquipment.Okpd;
            PriceTextBox.Text = _selectedEquipment.Price.ToString();
            UnitComboBox.SelectedItem = _selectedEquipment.Unit;
            CommentRichTextBox.Document.Blocks.Clear();
            CommentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(_selectedEquipment.Comment)));
        }
    }

}
