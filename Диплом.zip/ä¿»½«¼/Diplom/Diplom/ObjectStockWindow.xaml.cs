﻿using Diplom.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для ObjectStockWindow.xaml
    /// </summary>
    public partial class ObjectStockWindow : Window
    {
        private List<EquipmentStockModel> _originalEquipmentList;

        public event EventHandler<EquipmentStockModelEventArgs> EquipmentSelected;

        public ObjectStockWindow()
        {
            InitializeComponent();
            LoadStockEquipment();
        }

        private void LoadStockEquipment()
        {
            using (var context = new MarketContext())
            {
                var equipmentList = context.Stocks
                    .Where(s => s.Type == "main")
                    .SelectMany(s => s.EqupmentsStocks)
                    .AsNoTracking() // Отключаем отслеживание контекстом
                    .Select(es => new EquipmentStockModel
                    {
                        IdEqupment = es.IdEqupment,
                        IdStock = es.IdStock,
                        Name = es.IdEqupmentNavigation.Name,
                        Description = es.IdEqupmentNavigation.Description,
                        Manufacturer = es.IdEqupmentNavigation.Manufacturer,
                        Model = es.IdEqupmentNavigation.Model,
                        Country = es.IdEqupmentNavigation.Country,
                        Okpd = es.IdEqupmentNavigation.Okpd,
                        Price = es.IdEqupmentNavigation.Price,
                        Unit = es.IdEqupmentNavigation.Unit,
                        Comment = string.IsNullOrEmpty(es.IdEqupmentNavigation.Comment) ? "Без комментария" : es.IdEqupmentNavigation.Comment,
                        Count = es.Count,
                        TotalPrice = es.Count * es.IdEqupmentNavigation.Price
                    })
                    .ToList();

                _originalEquipmentList = equipmentList;
                DGridProductsList.ItemsSource = _originalEquipmentList;
            }
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl && tabControl.SelectedItem is TabItem selectedItem)
            {
                UpdateFilteredEquipmentList(selectedItem);
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateFilteredEquipmentList();
        }

        private void UpdateFilteredEquipmentList(TabItem selectedTab = null)
        {
            var filter = SearchTextBox.Text.ToLower();
            var selectedType = (selectedTab != null && selectedTab.Header.ToString() != "Все типы") ? selectedTab.Header.ToString() : null;

            var filteredList = _originalEquipmentList
                .Where(item =>
                    (selectedType == null || item.Type == selectedType) &&
                    (item.Name.ToLower().Contains(filter) ||
                     item.Description.ToLower().Contains(filter) ||
                     item.Manufacturer.ToLower().Contains(filter) ||
                     (item.Model != null && item.Model.ToLower().Contains(filter)) ||
                     item.Country.ToLower().Contains(filter) ||
                     item.Okpd.ToLower().Contains(filter)))
                .ToList();

            DGridProductsList.ItemsSource = filteredList;
        }

        private void MoveObject_Click(object sender, RoutedEventArgs e)
        {
            if (DGridProductsList.SelectedItem is EquipmentStockModel selectedEquipment)
            {
                EquipmentSelected?.Invoke(this, new EquipmentStockModelEventArgs { SelectedEquipment = selectedEquipment });
                this.Close();
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    public class EquipmentStockModelEventArgs : EventArgs
    {
        public EquipmentStockModel SelectedEquipment { get; set; }
    }
}


