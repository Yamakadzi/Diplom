﻿using Diplom.Data;
using Diplom.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddInStockWindow.xaml
    /// </summary>
    public partial class AddInStockWindow : Window
    {
        public event EventHandler ItemAddedSuccessfully;
        private string itemType;
        public AddInStockWindow(string itemType)
        {
            InitializeComponent();
            this.itemType = itemType;
            InitializeComboBoxes();
        }

        private void InitializeComboBoxes()
        {
            // Заполнение CountryComboBox
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            // Заполнение UnitComboBox
            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

            var type = new List<string> { "Оборудование", "Расходные материалы", "Инструменты" };
            TypeComboBox.ItemsSource = type;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new MarketContext())
            {
                // Получаем IdStock для склада "main"
                int mainStockId = 2;

                // Создаем новый объект Equipment
                var newEquipment = new Equipment
                {
                    Name = NameTextBox.Text,
                    Type = TypeComboBox.SelectedItem?.ToString(),
                    Description = new TextRange(DescriptionRichBox.Document.ContentStart, DescriptionRichBox.Document.ContentEnd).Text,
                    Manufacturer = ManufacturerTextBox.Text,
                    Model = ModelTextBox.Text,
                    Country = CountryComboBox.SelectedItem?.ToString(),
                    Okpd = OkpdTextBox.Text,
                    Unit = UnitComboBox.SelectedItem?.ToString(), // Добавляем значение Unit
                    Price = decimal.Parse(PriceTextBox.Text),
                    Comment = string.IsNullOrWhiteSpace(new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text)
        ? "Без комментария" : new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text
                };

                // Создаем новый объект EqupmentsStock и указываем IdStock = mainStockId
                var newEquipmentStock = new EqupmentsStock
                {
                    Count = int.Parse(CountTextBox.Text),
                    IdStock = mainStockId // Указываем IdStock для склада "main"
                };

                // Добавляем новый объект EqupmentsStock в список EqupmentsStocks объекта Equipment
                newEquipment.EqupmentsStocks.Add(newEquipmentStock);

                // Добавляем новый объект в DbSet Equipment
                context.Equipments.Add(newEquipment);

                // Сохраняем изменения в базе данных
                context.SaveChanges();

                // Сигнализируем об успешном добавлении предмета
                ItemAddedSuccessfully?.Invoke(this, EventArgs.Empty);

                // Закрываем окно
                this.Close();
            }
        }
    }
}
