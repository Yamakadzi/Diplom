﻿using Diplom.Data;
using Diplom.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddInStockWindow.xaml
    /// </summary>
    public partial class AddInStockWindow : Window
    {
        public event EventHandler ItemAddedSuccessfully;
        private string itemType;

        public AddInStockWindow(string itemType)
        {
            InitializeComponent();
            this.itemType = itemType;
            InitializeComboBoxes();
        }

        private void InitializeComboBoxes()
        {
            // Заполнение CountryComboBox
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            // Заполнение UnitComboBox
            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

            var type = new List<string> { "Оборудование", "Расходные материалы", "Инструменты" };
            TypeComboBox.ItemsSource = type;
        }

        public void FillFields(EditEquipmentModel selectedEquipment)
        {
            NameTextBox.Text = selectedEquipment.Name;
            TypeComboBox.SelectedItem = selectedEquipment.Type;
            DescriptionRichBox.Document.Blocks.Clear();
            DescriptionRichBox.Document.Blocks.Add(new Paragraph(new Run(selectedEquipment.Description)));
            ManufacturerTextBox.Text = selectedEquipment.Manufacturer;
            ModelTextBox.Text = selectedEquipment.Model;
            CountryComboBox.SelectedItem = selectedEquipment.Country;
            OkpdTextBox.Text = selectedEquipment.Okpd;
            PriceTextBox.Text = selectedEquipment.Price.ToString();
            UnitComboBox.SelectedItem = selectedEquipment.Unit;
            CommentRichTextBox.Document.Blocks.Clear();
            CommentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(selectedEquipment.Comment)));
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что пользователь ввел количество
            if (string.IsNullOrWhiteSpace(CountTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите количество предмета.");
                return;
            }

            if (!int.TryParse(CountTextBox.Text, out int count) || count <= 0)
            {
                MessageBox.Show("Введите корректное количество предмета.");
                return;
            }

            // Продолжаем сохранение только если количество введено
            using (var context = new MarketContext())
            {
                // Получаем введенные значения
                var description = new TextRange(DescriptionRichBox.Document.ContentStart, DescriptionRichBox.Document.ContentEnd).Text.Trim();
                var comment = new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text.Trim();

                // Ищем предмет по всем параметрам в таблице Equipments
                var existingEquipment = context.Equipments.FirstOrDefault(eq =>
                    eq.Name == NameTextBox.Text &&
                    eq.Type == TypeComboBox.SelectedItem.ToString() &&
                    eq.Description == description &&
                    eq.Manufacturer == ManufacturerTextBox.Text &&
                    eq.Model == ModelTextBox.Text &&
                    eq.Country == CountryComboBox.SelectedItem.ToString() &&
                    eq.Okpd == OkpdTextBox.Text &&
                    eq.Unit == UnitComboBox.SelectedItem.ToString() &&
                    eq.Comment == comment);

                // Если предмет не найден в таблице Equipments, сообщаем об этом и выходим из метода
                if (existingEquipment == null)
                {
                    MessageBox.Show("Предмет не найден в базе данных.");
                    return;
                }

                // Проверяем, есть ли уже этот предмет на складе main
                var existingItemInStock = context.EqupmentsStocks.FirstOrDefault(es =>
                    es.IdEqupment == existingEquipment.IdEquipment &&
                    es.IdStockNavigation.Type == "main");

                if (existingItemInStock != null)
                {
                    // Обновляем количество предмета на складе
                    existingItemInStock.Count += count;
                }
                else
                {
                    // Создаем новый объект EqupmentsStock
                    var newEquipmentStock = new EqupmentsStock
                    {
                        Count = count,
                        IdEqupment = existingEquipment.IdEquipment,
                        IdStock = context.Stocks.FirstOrDefault(s => s.Type == "main").IdStock
                    };

                    // Добавляем новый объект EqupmentsStock в DbSet EqupmentsStock
                    context.EqupmentsStocks.Add(newEquipmentStock);
                }

                // Сохраняем изменения в базе данных
                context.SaveChanges();

                // Сигнализируем об успешном добавлении предмета
                ItemAddedSuccessfully?.Invoke(this, EventArgs.Empty);

                // Закрываем окно
                this.Close();
            }
        }
        private string GetRichTextBoxText(RichTextBox richTextBox)
        {
            var textRange = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
            return textRange.Text;
        }
    }
}
