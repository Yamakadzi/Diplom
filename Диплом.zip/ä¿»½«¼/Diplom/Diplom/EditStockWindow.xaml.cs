﻿using Diplom.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для EditStockWindow.xaml
    /// </summary>
    public partial class EditStockWindow : Window
    {
        private EditEquipmentModel _equipmentToEdit;

        public EditStockWindow(EditEquipmentModel equipmentToEdit)
        {
            InitializeComponent();
            InitializeComboBoxes();
            _equipmentToEdit = equipmentToEdit;
            LoadSelectedEquipmentData();
        }

        private void InitializeComboBoxes()
        {
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

            var types = new List<string> { "Оборудование", "Расходные материалы", "Инструменты" };
            TypeComboBox.ItemsSource = types;
        }

        private void LoadSelectedEquipmentData()
        {
            NameTextBox.Text = _equipmentToEdit.Name;
            TypeComboBox.SelectedItem = _equipmentToEdit.Type;
            DescriptionRichBox.Document.Blocks.Clear();
            DescriptionRichBox.Document.Blocks.Add(new Paragraph(new Run(_equipmentToEdit.Description)));
            ManufacturerTextBox.Text = _equipmentToEdit.Manufacturer;
            ModelTextBox.Text = _equipmentToEdit.Model;
            CountryComboBox.SelectedItem = _equipmentToEdit.Country;
            OkpdTextBox.Text = _equipmentToEdit.Okpd;
            PriceTextBox.Text = _equipmentToEdit.Price.ToString();
            CountTextBox.Text = _equipmentToEdit.Count.ToString();
            UnitComboBox.SelectedItem = _equipmentToEdit.Unit;
            CommentRichTextBox.Document.Blocks.Clear();
            CommentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(_equipmentToEdit.Comment)));
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(CountTextBox.Text, out int count) && decimal.TryParse(PriceTextBox.Text, out decimal price))
            {
                using (var context = new MarketContext())
                {
                    var equipment = context.Equipments.FirstOrDefault(e => e.IdEquipment == _equipmentToEdit.IdEqupment);
                    var equipmentInStock = context.EqupmentsStocks.FirstOrDefault(es => es.IdEqupment == _equipmentToEdit.IdEqupment && es.IdStock == _equipmentToEdit.IdStock);

                    if (equipment != null && equipmentInStock != null)
                    {
                        equipment.Name = NameTextBox.Text;
                        if (TypeComboBox.SelectedItem != null)
                        {
                            equipment.Type = TypeComboBox.SelectedItem.ToString();
                        }
                        equipment.Description = new TextRange(DescriptionRichBox.Document.ContentStart, DescriptionRichBox.Document.ContentEnd).Text.Trim();
                        equipment.Manufacturer = ManufacturerTextBox.Text;
                        equipment.Model = ModelTextBox.Text;
                        if (CountryComboBox.SelectedItem != null)
                        {
                            equipment.Country = CountryComboBox.SelectedItem.ToString();
                        }
                        equipment.Okpd = OkpdTextBox.Text;
                        equipment.Price = price;
                        if (UnitComboBox.SelectedItem != null)
                        {
                            equipment.Unit = UnitComboBox.SelectedItem.ToString();
                        }
                        equipment.Comment = string.IsNullOrWhiteSpace(new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text.Trim()) ? "Без комментария" : new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text.Trim();

                        equipmentInStock.Count = count;

                        context.SaveChanges();
                        MessageBox.Show("Данные успешно обновлены.");
                        this.Close();

                        // После успешного сохранения, вызовите метод LoadStockEquipment у окна InfoStockPage
                        var mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                        if (mainWindow != null)
                        {
                            var infoStockPage = mainWindow.Content as InfoStockPage;
                            infoStockPage?.LoadStockEquipment(infoStockPage.TabControl.SelectedItem is TabItem selectedItem ? selectedItem.Header.ToString() : null);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при обновлении данных.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите корректные значения для количества и цены.");
            }
        }
    }
}
