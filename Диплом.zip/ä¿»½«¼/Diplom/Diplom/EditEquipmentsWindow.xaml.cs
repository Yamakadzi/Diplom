﻿using Diplom.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для EditEquipmentsWindow.xaml
    /// </summary>
    public partial class EditEquipmentsWindow : Window
    {
        private EditEquipmentModel _editEquipment;

        public event EventHandler ItemEditedSuccessfully;

        public EditEquipmentsWindow(EditEquipmentModel editEquipment)
        {
            InitializeComponent();
            InitializeComboBoxes();
            _editEquipment = editEquipment;

            // Инициализируем элементы управления значениями из модели
            NameTextBox.Text = _editEquipment.Name;
            TypeComboBox.SelectedItem = _editEquipment.Type;
            DescriptionRichBox.Document.Blocks.Clear();
            DescriptionRichBox.Document.Blocks.Add(new Paragraph(new Run(_editEquipment.Description)));
            ManufacturerTextBox.Text = _editEquipment.Manufacturer;
            ModelTextBox.Text = _editEquipment.Model;
            CountryComboBox.SelectedItem = _editEquipment.Country;
            OkpdTextBox.Text = _editEquipment.Okpd;
            PriceTextBox.Text = _editEquipment.Price.ToString();
            UnitComboBox.SelectedItem = _editEquipment.Unit;
            CommentRichTextBox.Document.Blocks.Clear();
            CommentRichTextBox.Document.Blocks.Add(new Paragraph(new Run(_editEquipment.Comment)));
        }

        private void InitializeComboBoxes()
        {
            // Заполнение CountryComboBox
            var countries = new List<string> { "Россия", "Китай", "Япония", "США", "Германия", "Франция", "Италия", "Испания" };
            CountryComboBox.ItemsSource = countries;

            // Заполнение UnitComboBox
            var units = new List<string> { "шт", "упаковка", "комплект" };
            UnitComboBox.ItemsSource = units;

            var types = new List<string> { "Оборудование", "Расходные материалы", "Инструменты" };
            TypeComboBox.ItemsSource = types;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text.Trim();
            string type = TypeComboBox.SelectedItem as string;
            string description = new TextRange(DescriptionRichBox.Document.ContentStart, DescriptionRichBox.Document.ContentEnd).Text.Trim();
            string manufacturer = ManufacturerTextBox.Text.Trim();
            string? model = ModelTextBox.Text.Trim();
            string country = CountryComboBox.SelectedItem as string;
            string okpd = OkpdTextBox.Text.Trim();
            string unit = UnitComboBox.SelectedItem as string;
            decimal price;
            string comment = new TextRange(CommentRichTextBox.Document.ContentStart, CommentRichTextBox.Document.ContentEnd).Text.Trim();

            // Проверка ввода данных
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(type) || string.IsNullOrEmpty(description) ||
                string.IsNullOrEmpty(manufacturer) || string.IsNullOrEmpty(country) || string.IsNullOrEmpty(okpd) ||
                string.IsNullOrEmpty(unit) || !decimal.TryParse(PriceTextBox.Text, out price))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                return;
            }

            // Обновляем модель значениями из элементов управления
            _editEquipment.Name = name;
            _editEquipment.Type = type;
            _editEquipment.Description = description;
            _editEquipment.Manufacturer = manufacturer;
            _editEquipment.Model = model;
            _editEquipment.Country = country;
            _editEquipment.Okpd = okpd;
            _editEquipment.Unit = unit;
            _editEquipment.Price = price;
            _editEquipment.Comment = comment;

            // Сохраняем изменения в базу данных
            using (var context = new MarketContext())
            {
                var equipment = context.Equipments.Find(_editEquipment.IdEqupment);
                if (equipment != null)
                {
                    equipment.Name = _editEquipment.Name;
                    equipment.Type = _editEquipment.Type;
                    equipment.Description = _editEquipment.Description;
                    equipment.Manufacturer = _editEquipment.Manufacturer;
                    equipment.Model = _editEquipment.Model;
                    equipment.Country = _editEquipment.Country;
                    equipment.Okpd = _editEquipment.Okpd;
                    equipment.Unit = _editEquipment.Unit;
                    equipment.Price = _editEquipment.Price;
                    equipment.Comment = _editEquipment.Comment;

                    context.SaveChanges();
                }
            }

            MessageBox.Show("Предмет успешно отредактирован.");
            ItemEditedSuccessfully?.Invoke(this, EventArgs.Empty); // Уведомление об успешном редактировании
            Close();
        }
    }
}
