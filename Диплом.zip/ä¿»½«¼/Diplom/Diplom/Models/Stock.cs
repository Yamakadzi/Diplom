﻿using System;
using System.Collections.Generic;

namespace Diplom.Models;

public partial class Stock
{
    public int IdStock { get; set; }

    public string Name { get; set; } = null!;

    public string Type { get; set; } = null!;

    public virtual Auditorium? Auditorium { get; set; }

    public virtual ICollection<EqupmentsStock> EqupmentsStocks { get; } = new List<EqupmentsStock>();
}
