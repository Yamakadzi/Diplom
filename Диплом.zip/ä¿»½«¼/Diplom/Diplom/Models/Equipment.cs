﻿using System;
using System.Collections.Generic;

namespace Diplom.Models;

public partial class Equipment
{
    public int IdEquipment { get; set; }

    public string Name { get; set; } = null!;

    public string Type { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string Okpd { get; set; } = null!;

    public string Manufacturer { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string? Model { get; set; }

    public string Unit { get; set; } = null!;

    public decimal Price { get; set; }

    public string? Сomment { get; set; }

    public virtual ICollection<EqupmentsStock> EqupmentsStocks { get; set; } = new List<EqupmentsStock>();
}
