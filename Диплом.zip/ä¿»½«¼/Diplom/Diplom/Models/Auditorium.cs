﻿using System;
using System.Collections.Generic;

namespace Diplom.Models;

public partial class Auditorium
{
    public int IdAuditorium { get; set; }

    public string Name { get; set; } = null!;

    public int IdStock { get; set; }

    public virtual Stock IdStockNavigation { get; set; } = null!;
}
