﻿using System;
using System.Collections.Generic;

namespace Diplom.Models;

public partial class EqupmentsStock
{
    public int IdEqupment { get; set; }

    public int IdStock { get; set; }

    public int Count { get; set; }

    public virtual Equipment IdEqupmentNavigation { get; set; } = null!;

    public virtual Stock IdStockNavigation { get; set; } = null!;
}
