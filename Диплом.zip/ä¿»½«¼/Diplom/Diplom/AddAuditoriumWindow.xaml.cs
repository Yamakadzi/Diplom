﻿using Diplom.Data;
using Diplom.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddAuditoriumWindow.xaml
    /// </summary>
    public partial class AddAuditoriumWindow : Window
    {
        public event EventHandler ItemAddedSuccessfully;
        public AddAuditoriumWindow()
        {
            InitializeComponent();
        }

        private void AddAuditoriumButton_Click(object sender, RoutedEventArgs e)
        {
            string auditoriumName = AuditoriaTextBox.Text.Trim();

            if (string.IsNullOrEmpty(auditoriumName))
            {
                MessageBox.Show("Введите название аудитории.");
                return;
            }

            using (var context = new MarketContext())
            {
                // Проверяем, существует ли аудитория с таким же названием
                bool auditoriumExists = context.Auditoria.Any(a => a.Name == auditoriumName);

                if (auditoriumExists)
                {
                    MessageBox.Show("Аудитория с таким названием уже существует.");
                    return;
                }

                // Создаем новый объект Stock с типом "auditorium"
                var newStock = new Stock
                {
                    Name = auditoriumName,
                    Type = "auditorium"
                };

                context.Stocks.Add(newStock);
                context.SaveChanges();

                // Создаем новый объект Auditorium и связываем его с новым складом
                var newAuditorium = new Auditorium
                {
                    Name = auditoriumName,
                    IdStock = newStock.IdStock
                };

                context.Auditoria.Add(newAuditorium);
                context.SaveChanges();

                MessageBox.Show("Аудитория успешно добавлена.");

                // Оповещаем о том, что аудитория успешно добавлена
                ItemAddedSuccessfully?.Invoke(this, EventArgs.Empty);
            }

            this.Close();
        }
    }
}
